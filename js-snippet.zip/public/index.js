

const css = `
#urbnups-moments-widget {
    font-family: 'Poppins', sans-serif !important;
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px;
    width: 100%; 
    display: grid;
    /* Define Auto Row size */
    grid-auto-rows: 400px; 
    /*Define our columns */
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); 
    grid-gap: 1em;
  }

.urbnups_moment {
    width: 315px;
    text-align: left;
}

.urbnups_moment_image img {
    width: 315px;
    height: 315px;
    border-radius: 8px 8px 8px 8px;
}

.urbnups_moment_creator {
    position: absolute;
    margin-left: 10px;
    margin-top: 10px;
    font-family: 'Poppins', sans-serif !important;

}

.urbnups_moment_creator img {
    width: 30px;
    height: 30px;
    object-fit: cover;
    border-radius: 35px 35px 35px 35px;
}

.urbnups_moment_creator a {
    color: white;
    text-decoration: none;
    font-size: 12px;
    font-weight: 600;
    font-family: 'Poppins', sans-serif !important;


}

.urbnups_moment_creator a div {
    align-items: center;
    display: flex
}

.urbnups_moment_creator a div span {
    padding-left: 10px
    font-family: 'Poppins', sans-serif !important;

}

.urbnups_moment_title {
    font-size: 14px;
    font-weight: 600;
    font-family: 'Poppins', sans-serif !important;


}

.urbnups_moment_description {
    font-size: 11px;
    font-weight: 300;
    font-family: 'Poppins', sans-serif !important;

}

.urbnups_moment_favourite {
    position: absolute;
    margin-left: 265px;
    margin-top: -25px
    font-family: 'Poppins', sans-serif !important;

}

.urbnups_moment_favourite img {
    width: 40px;
    height: 40px;
    object-fit: contain;
}`

async function getData() {
    try {
        let data = await fetch("http://localhost:3002/api/moments")
        return data.json();
    } catch (error) {
        console.log("error ocuured")
    }

}

window.addEventListener('DOMContentLoaded', async (event) => {

    const arry = await getData()

    if (arry) {
        let getEle = document.getElementsByTagName("urbnups-moments-widget");
        getEle = getEle[0];

        // console.log(getEle.getAttribute("widget-id"))

        const main = document.createElement("div")
        main.setAttribute("id", 'urbnups-moments-widget');


        for (let i = 0; i < arry.length; i++) {
            const data = arry[i];
            var html = `
   
        <div class="urbnups_moment_creator">
            <a href=${data.deeplink} target='_blank'>
            <div>
            <img  src="${data.userPreviewImage}" >
            <span> ${data.displayName}</span>
            </div>
            </a>
        </div>
         <div class="urbnups_moment_image">
         <a href=${data.deeplink} target='_blank'>
         <img src=${data.previewImage} width=315px />
         </a>
         </div>
         <div class="urbnups_moment_favourite">
         <img src="https://urbnups.com/wp-content/uploads/2022/10/bucketlisticon.png">
         </div>
         <div class="urbnups_moment_title">
         <span>${data.name}</span>
         </div>
        <div class="urbnups_moment_description">
         <span>${data.description_snippet}</span>
         </div>
    `;

            const newdiv = document.createElement('div');
            newdiv.setAttribute('class', "urbnups_moment");
            newdiv.innerHTML = html
            main.appendChild(newdiv)

        }

        var styleNode = document.createElement('style');
        styleNode.type = "text/css";
        if (!!(window.attachEvent && !window.opera)) {
            styleNode.styleSheet.cssText = css;
        } else {
            var styleText = document.createTextNode(css);
            styleNode.appendChild(styleText);
        }
        document.getElementsByTagName('head')[0].appendChild(styleNode);

        //         <link rel="preconnect" href="https://fonts.googleapis.com">
        // <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        // <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap" rel="stylesheet"></link>

        //font link
        var fontLink = document.createElement('link');
        fontLink.type = 'text/css';
        fontLink.rel = 'stylesheet';
        document.head.appendChild(fontLink);
        fontLink.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swapt'

        var gStatic = document.createElement('link');
        gStatic.rel = 'preconnect';
        document.head.appendChild(gStatic);
        gStatic.href = 'https://fonts.gstatic.com'
        gStatic.crossOrigin = "true"

        var fontApi = document.createElement('link');
        fontApi.rel = 'preconnect';
        document.head.appendChild(fontApi);
        fontApi.href = "https://fonts.googleapis.com"


        getEle.insertAdjacentElement("afterend", main);
        getEle.remove()
    }
});